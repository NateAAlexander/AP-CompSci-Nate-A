public class FirstProject {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        for(String word : args) {
            System.out.println(word);
        }
    }
}    